
Ext.require([
    'Ext.plugin.Viewport'
]);
Ext.onReady(function(){
    Ext.create('Ext.form.Panel', {
		title: 'INGRESAR AL SISTEMA DE RESULTADOS',
		renderTo: Ext.get("espacio1"),
		bodyPadding: 5,
		style: 'margin-top:100px;margin-bottom:100px;marginleft:450px;',
		width: "40em",
		height: "20em",
		url: "login.php",
		standardSubmit: false, //para request parcial
		defaultType: 'textfield',
		items: [{
				fieldLabel: 'ID ADMIN',
				name: 'txtCve',
				width:"30em",
				height:"3em",
				style:'margin-top:20px;margin-bottom:20px;margin-left:40px;',
				regex: /^[0-9]+$/,
				invalidText: 'Sólo números'
			},
			{
				fieldLabel: 'Contrase&ntilde;a',
				name: 'txtPwd',
				inputType: 'Contrase&ntilde;a',
				width:"30em",
				height:"3em",
				style:'margin-top:20px;margin-bottom:20px;margin-left:40px;',
				allowBlank: false
			}],
		buttons: [{
			text: 'INGRESAR',
			handler: function() {
				var frm = this.up('form').getForm();
				if (frm.isValid()) {
					// Envío "normal", viaja de forma parcial por la configuración inicial
					frm.submit({
						success: function(form, action) {
							window.location.href = "inicioAdmin.php";
						},
						failure: function(form, action) {
							Ext.Msg.alert('Error', action.result ? action.result.sNom : 'Sin respuesta');
						}
					});
				}
			}
		}]
	});
});
